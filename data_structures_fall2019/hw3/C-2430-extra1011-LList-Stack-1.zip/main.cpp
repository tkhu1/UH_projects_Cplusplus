#include "ArgumentManager.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

///////////////////////////////////////////////////////////////////////////////////////
// AUTHOR: TYLER HU,   ID: 0276538                                                   //
//                                                                                   //
// Inspired by code posted by Dr. Rizk, Dr. Malik (textbook), and Geek4Geeks website //
///////////////////////////////////////////////////////////////////////////////////////

// NODE TEMPLATE //////////////////////////////////////////////////////////////////////
template <typename T>
class Node { 
	public:
    T data; 
    Node<T> *link; 

		//default constructor
    Node<T>()
    {
			this->data = -1;
			this->link = NULL;
    }
};

// LINKED LIST STACK TEMPLATE /////////////////////////////////////////////////////////
template <typename T>  
class LLstack { 
	public:
		//pointer to top of stack
    Node<T> *top; 

		//default constructor
		LLstack()
		{
			this->top = NULL;
		}

		//reinit stack to empty
		void reinitStack()
		{
			//pointer to delete node
			Node<T> *temp;

			//while there are elements in the stack
			while (top != NULL) {
				temp = top;
				top = top->link; 

				delete temp;
			}
		}

		//checks if stack is empty
		bool isEmpty() const
		{
			if (top == NULL)
				return true; 
			else
				return false;
		}

		//returns false as linked list is never full
		bool isFull () const
		{
			return false;
		}

		//adds data node to top of stack
		void push(T newData) 
		{
			//pointer to create the new node
			Node<T> *newNode = new Node<T>;

			newNode->data = newData; //copies data into node
			newNode->link = top;     //insert newNode before top of stack
			top = newNode;           //set top pointer to the new top node
		}

		//removes data node from top of stack
		void pop() 
		{
			//error checking
			if (top == NULL) 
				return;

			//pointer to delete node
			Node<T> *temp;

			//checks if stack is empty
			if (top != NULL)
			{ 
				temp = top;      //set temp to point to the top node
			  top = top->link; //moves top pointer to next node

				delete temp; //deletes top node
			}
			else
				cout << "\nCannot remove from an empty stack." << endl;
		}

		//returns data in top node of stack
		T peek()
		{
			//checks for empty stack 
    	if (!isEmpty()) 
        return top->data; 
    	else
				cout << "\nCannot peek at empty stack." << endl; 
        exit(0);
		}
};
		
// EXPRESSION EVALUATION FUNCTIONS ////////////////////////////////////////////////////
		
//returns priority of operator
int priority(char op)
{
	if (op == '(') {
		return 1;
	}
	else if (op == '+' || op == '-') {
		return 2;
	}
	else if (op == '*' || op == '/') {
		return 3;
	}
	else {
		//-1 represents error value
		return -1;
	}
}

//returns evaluated arithmetic block value
long long int calculator(char op, long long int lhs, long long int rhs)
{
	if (op == '+') {
		long long int result = lhs + rhs;
		return result;
	}
	else if (op == '-') {
		long long int result = lhs - rhs;
		return result;
	}
	else if (op == '*') {
		long long int result = lhs * rhs;
		return result;
	}
	else if (op == '/') {
		//checks if right hand operand is not 0
		if (rhs != 0) {
			long long int result = lhs/rhs;
			return result;
		}
		else {
			//-1 represents error value
			return -1;
		}
	}
	else {
		//-1 represents error value
		return -1;
	}
}

//evaluates input expression and returns result
long long int evaluator(string exp)
{
	//init two stacks for evaluation
	LLstack<char> opSt;
	LLstack<long long int> intSt;

	cout <<"Infix: " << exp << endl; //DEBUG

	//init string expression position limiter
	int i = 0;

	//avoids null char
	while (exp[i] != '\0') {
		if (exp[i] == '(') {
			opSt.push('(');
		}
		else if (exp[i] == ')') {
			//loops until next evaluation block is found
			while (opSt.peek() != '(') {
				long long int rhs = intSt.peek();
				intSt.pop();

				long long int lhs = intSt.peek();
				intSt.pop();

				//pushes result from arithmetic block
				long long int result = calculator(opSt.peek(), lhs, rhs);
				intSt.push(result);

				opSt.pop(); 
			}
			opSt.pop();
		}
		//checks if char is operator and evaluates expression arithmetic block
		else if (exp[i] == '+' || exp[i] == '-' || exp[i] == '*' || exp[i] == '/') {
			//stores char's priority
			int charPriority = priority(exp[i]);

			//handles priority arithmetic
			while(!opSt.isEmpty() && priority(opSt.peek()) >= charPriority) {
				long long int rhs = intSt.peek();
				intSt.pop();

				long long int lhs = intSt.peek();
				intSt.pop();

				//pushes result from arithmetic block
				long long int result = calculator(opSt.peek(), lhs, rhs);
				intSt.push(result);

				opSt.pop(); 
			}
			//pushes to operator stack
			opSt.push(exp[i]);
		}
		//pushes numbers to operand stack
		else {
			intSt.push(int(exp[i])-48);
		}
		i++;
	}

	while(!opSt.isEmpty()){
		long long int rhs = intSt.peek();
		intSt.pop();

		long long int lhs = intSt.peek();
		intSt.pop();

		long long int result = calculator(opSt.peek(), lhs, rhs);
		intSt.push(result);
		opSt.pop(); 
	}

	return (intSt.peek());
}

// MAIN FUNCTIONS /////////////////////////////////////////////////////////////////////

//checks if expression is valid 
bool isValid(string exp) 
{ 
	for (int i=0; i < exp.length(); i++) { 
		if (exp[i] != '(' ) {
			balSt.push(exp[i]);
		}
		else if (exp[i] == ')') {   
			//if first char is closing parentheses, expression is unbalanced
			if (balSt.isEmpty()) {
				return false;
			}

			c = balSt.peek();
			balSt.pop();
			
			//checks for matching pair
			if (exp[i] == ')' && c != '(')
				return false;
		}
	}
	//returns true if stack is empty
	if (balSt.isEmpty()) {
		return true;
	}
	else {
		return false;
	}
}

//checks if parantheses are balanced 
bool isBalanced(string exp) 
{ 
	LLstack<char> balSt; 
	char c; 

	//pushes open parentheses to stack
	for (int i=0; i < exp.length(); i++) { 
		if (exp[i] == '(') {
			balSt.push(exp[i]);
		}
		else if (exp[i] == ')') {   
			//if first char is closing parentheses, expression is unbalanced
			if (balSt.isEmpty()) {
				return false;
			}

			c = balSt.peek();
			balSt.pop();
			
			//checks for matching pair
			if (exp[i] == ')' && c != '(')
				return false;
		}
	}
	//returns true if stack is empty
	if (balSt.isEmpty()) {
		return true;
	}
	else {
		return false;
	}
}

//checks if char is * or / operator 
bool isOp(char op)
{
	if (op == '*' || op == '/') {
		return true;
	}
	return false;
}

// MAIN ///////////////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[]) {
	/*
	if (argc != 3 && argc != 2) {
		cout << "Invalid arguments" << endl;
		return 1;
	}

	ArgumentManager am(argc, argv);
	const string input = am.get("input");
	const string output = am.get("output");
*/

	//init input stream
	ifstream infs("input31.txt");

	//init output stream
	ofstream outfs("output.txt");

	//exits if input not found and writes error to output
	if (!infs) {
		outfs << "error" << endl;
		return 1;
	}

	//exits if input is empty and writes error to output
	//inspired by code from Stack Overflow website
	if ((infs.peek() == ifstream::traits_type::eof())) { 
		outfs << "error" << endl;
		return 1;
	}

	//holds input line
	string temp;

	//reads from input stream
	while (!infs.eof()) {
		getline(infs, temp);
		int lineSize = 0;
		//stores length of sentence line
		if (!temp.empty() && temp != "\r") {
			//input storage
			string line = "";
			//stores length of sentence line
			lineSize = temp.length();
			//cout << lineSize << " ";
			//avoids empty lines
			while (lineSize == 0) { 
				getline(infs, temp); 
				lineSize = temp.length();
			}
			//checks for empty strings
			if (lineSize != 0) {
				//checks for balanced and valid expressions
				if (isBalanced(temp) && !isOp(temp[0]) && !isOp(temp[lineSize-1]) {
					long long int result = evaluator(temp);
					outfs << temp << "=" << result << endl;
					//cout << temp << endl; //DEBUG
					//outfs << "balanced" << endl; //DEBUG
				}
				else {
					outfs << "error" << endl;
				}
			}
		}
	}

	infs.close();
	outfs.close();

	return 0;
}