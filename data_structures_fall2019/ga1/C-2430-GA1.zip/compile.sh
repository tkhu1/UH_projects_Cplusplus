g++ -std=c++11 *.cpp -o ga1
