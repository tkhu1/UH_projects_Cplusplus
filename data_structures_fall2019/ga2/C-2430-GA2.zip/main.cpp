#include <iostream>
#include <string>
#include <time.h> 

using namespace std;

/*
  GROUP CONSISTED OF TYLER HU & ARMANDO MATA & MITCHELL MONTVALVO
  WE ALL CONTRIBUTED TO THE CODE 
*/

//CLASSES//////////////////////////////////////////////////////////////////////////////
class Player
{
	public:
		int number;
		int age;
		int minutes;
		int position;
		string isOnCourt; //holds C/B value for player status

		//doubly linked list pointers
		Player *next;
		Player *prev;
		
		//default constructor
		Player() 
		{
			this->number = -1;
			this->age = -1;
			this->minutes = -1;
			this->position = -1;
			this->isOnCourt = "B";
			
			this->next = NULL;
			this->prev = NULL;
		}
		
		//constructor
		Player(int number, int age, int minutes, int position, string isOnCourt)
		{
			this->number = number;
			this->age = age;
			this->minutes = minutes;
			this->position = position;
			this->isOnCourt = isOnCourt;
			
			this->next = NULL;
			this->prev = NULL;
		}

		//returns string holding player position
		string getPosition(int posNum) 
		{
			posNum = posNum-1; //fits to array
			//ERROR checking
			if (posNum < 0 || posNum > 6) {
				cout << "ERROR: Invalid player position detected" << endl;
				exit(0);
			}

			//array of player positions
			const string positionList[7] = { "Point Guard (PG)",
																		   "Shooting Guard(SG)", 
																		   "Small Forward (SF)", 
																			 "Power Forward (PF)", 
																			 "Center (C)",
					                             "Forward-Center (FC)", 
					                             "Guard-Forward (GF)" };

			return positionList[posNum];																 
		}
};

class Bench
{
	public:
		//pointers
		Player *head;
		Player *tail;

		//constructor
		Bench()
		{
			this->head = NULL;
			this->tail = NULL;
		}
		
		void addFirst() 
		{
				
		}
		
		//adds empty player node to end of doubly linked bench
		void addEnd(Player *baller)
		{
			//creates head node if list is empty
			if (head == NULL) {
				head = baller;
				tail = baller;
				
				return;
			}
			
			baller->prev = tail; //sets new node 'previous' to tail
			tail->next = baller; //sets tail 'next' to new node
			tail = baller;       //new node is now tail
		}
		
		void getFirst() 
		{
				
		}
		
		void getLast() 
		{
				
		}
		
		
		void get() 
		{
				
		}
		
		//edits existing node
		void set() 
		{
				
		}
		
		//FOR DEBUG
		void print()
		{
			cout << "Bench: ";
			
			Player *temp = head; //CCes head pointer
			
			while (temp != NULL) {
				cout << temp->number;
				if (temp->next != NULL)
						cout << " ";
				temp = temp->next;
			}
			
			cout << endl;
		}
};

class Court
{
  public:
    Player *head;
    Player *tail;
    int size;
    
		//default constructor
    Court()
    {
			this->head = NULL;
			this->tail = NULL;
			this->size = 0;
    }

    //adds empty player node to end of circularly double linked court
    void addEnd(Player *baller)
    {
			//increments number of players on court for sorting needs
			++size;
			//creates head node if list is empty
			if (head == NULL) {
				head = baller;
				tail = baller;
						
				return;
			}
			
			baller->prev = tail; //sets new node 'previous' to tail
			tail->next = baller; //sets tail 'next' to new node
			tail = baller;       //new node is now tail
			tail->next = head;   //loops new tail back to head
    }
    
		//edits existing node
    void set() 
		{
        
    }
    
		//returns the pointer to the specified player node
    Player *getBallerIndex(int ballerIndex)
    {
			//ERROR checking
			if (head == NULL)
				return NULL;
			if (ballerIndex < 0 || ballerIndex >= size) {
				cout << "ERROR: Invalid player selection entered" << endl;
				return NULL;
			}
			
			Player *temp = head; //CCes head pointer
			int counter = 0;

			while (temp != NULL) {
				if (counter == ballerIndex)
					return temp;
				
				temp = temp->next;
				++counter;
			}
			//if not found
			return NULL;
    }
    
		//FOR DEBUG
    void print()
    {
			cout << "Court: ";
			
			Player *temp = head; //CCes head pointer
					
			while (temp != NULL) {
				cout << temp->number;
				if (temp->next != head)
						cout << " ";
				else
					break;

				temp = temp->next;
			}
					
			cout << endl;
    }
    
		//sorts the court by player number
    void sort()
    {
			//bubble sort
			for (int i=0; i < size-1; i++) {
				for (int j=0; j < size-i-1; j++) {
					//retrieves nodes
					Player *baller1 = getBallerIndex(j);
					Player *baller2 = getBallerIndex(j+1);
				
					//sorts by player number
					if (baller1->number > baller2->number) {
						//swaps player 1 and 2
						int temp = baller1->number;
						baller1->number = baller2->number;
						baller2->number = temp;
					}
				}
    	}
		}
};

int main()
{
	//init dynamic array of Player classes
	Player *lockerRoom = new Player[12];

	//init court obj
	Court gameCourt;
	for (int i = 1; i <= 5; i++) { //i is player number

		//creates player nodes for initial court at start of game
		//                    (number, age, time, position, status)
		Player *c = new Player(i, (i+18+i), 0, i, "C");
		gameCourt.addEnd(c);
	}
	
	gameCourt.sort();
	gameCourt.print(); //DEBUG

	//init bench obj
	Bench gameBench;
	for (int i = 6; i <= 12; i++) { //i is player number

		//creates player nodes for initial bench at start of game
		//                    (number, age, time, position, status)
		Player *b = new Player(i, (i+13+i), 0, (i-5), "B");
		gameBench.addEnd(b);
	}

	gameBench.print(); //DEBUG

	/* 	TO-DO LIST

	*make input list of player names to pull from (James Harden, Russell Westbrook, etc)

	*randomize players from arrays of non duplicate jersey nums and ages?
	 (see player position function)

	*populate locker room and then randomize selection of starters from locker room?

	*add/remove from bench and court

	*time counting function(s)

	*quarter (4x12 minutes) handling function?

	*merge court and bench at end of game

	*output report functions

	*/
	
	delete [] lockerRoom;

	return 0;
}